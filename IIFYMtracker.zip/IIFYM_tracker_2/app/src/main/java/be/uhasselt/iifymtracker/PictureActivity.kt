package be.uhasselt.iifymtracker

import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import be.uhasselt.iifymtracker.databinding.ActivityPictureBinding
import com.google.android.material.snackbar.Snackbar

class PictureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPictureBinding
    private lateinit var pictureActivityResult: ActivityResultLauncher<Void>
    private val REQ_PIC_ID = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPictureBinding.inflate(layoutInflater) //maakt een verborgen klasse voor xml activity_main
        setContentView(binding.root)

        pictureActivityResult = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bm: Bitmap ->
            msg("Congratulations, you've taken a picture", binding.root)
            binding.idPhoto.setImageBitmap(bm)
        }

        binding.btnTakepic.setOnClickListener(this::AttemptPicture)
    }

    private fun AttemptPicture(view: View) {
        takePicture()
    }

    private fun takePicture() {
        pictureActivityResult.launch(null)
    }



    private fun msg(text: String, view: View) {
        Snackbar.make(view, text, Snackbar.LENGTH_LONG)
            .setAction("Action", null).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if(grantResults.isEmpty() || grantResults.first() != PackageManager.PERMISSION_GRANTED) {
            msg("geen permissie!", binding.root)
            return
        }

        when(requestCode) {
            REQ_PIC_ID -> takePicture()
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}