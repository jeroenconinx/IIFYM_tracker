package be.uhasselt.iifymtracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import be.uhasselt.iifymtracker.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    public var list = arrayListOf(
        Foodlist("pizza", 31, 120, 34),
        Foodlist("taart", 22,60,5),
        Foodlist("vlees", 4,25, 1),
        Foodlist("rijst", 1, 81, 8),
        Foodlist("brood", 4,55, 14),
        Foodlist("kaas", 24,5, 19),
        Foodlist("mayo", 80,1, 3),
        Foodlist("vis", 24,5, 19),
        Foodlist("spaghet", 24,5, 19),
        Foodlist("snoep", 24,5, 19)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) //maakt een verborgen klasse voor xml activity_main
        setContentView(binding.root)

        binding.button.setOnClickListener (this::switch)
        binding.idInfoButton.setOnClickListener(this:: Info)

        val kcalgoal = intent.getIntExtra("fats", 0)
        val kcal = kcalgoal*44
        binding.vetVoedsel.text = kcal.toString()

        var adapter = ListAdapter(list)
        binding.rvList.adapter = adapter
        binding.rvList.layoutManager = LinearLayoutManager(this)

        binding.idAddButon.setOnClickListener{
            var naam = binding.idName.text.toString()
            var fat: Int = binding.idFat.text.toString().toInt()
            var carbs = binding.idCarbs.text.toString().toInt()
            var prot = binding.idProtein.text.toString().toInt()

            list.add(Foodlist(naam.toString(), fat, carbs, prot))
            adapter.notifyItemInserted(list.size - 1)
        }
    }

    private fun Info(view: View){
        val intent = Intent(this, InfoActivity::class.java)
        startActivity(intent)
    }

    private fun switch(view: View){
        var x = 143
        val intent = Intent(this, ExtraActivity::class.java)
        intent.putExtra("tekst", x.toString())
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.menuProteininformation-> {
                getProteinInformation()
                true
            }
            R.id.menuPicture-> {
                getPicture()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun getPicture() {
        val intent = Intent(this, PictureActivity::class.java)
        startActivity(intent)
    }

    private fun getProteinInformation() {
        val intent = Intent(this, ProteinInfo::class.java)
        startActivity(intent)
    }
}