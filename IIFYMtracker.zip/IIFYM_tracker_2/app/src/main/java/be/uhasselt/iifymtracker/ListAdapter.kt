package be.uhasselt.iifymtracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ListAdapter(
    var list: List<Foodlist>) :
RecyclerView.Adapter<be.uhasselt.iifymtracker.ListAdapter.FoodlistViewHolder>() {

    inner class FoodlistViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodlistViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list, parent, false)
        return FoodlistViewHolder(view)
    }

    override fun onBindViewHolder(holder: FoodlistViewHolder, position: Int) {
        holder.itemView.apply {
            findViewById<TextView>(R.id.foodnaam).text = list[position].naam
            findViewById<TextView>(R.id.prot).text = list[position].prot.toString()
            findViewById<TextView>(R.id.carb).text = list[position].carb.toString()
            findViewById<TextView>(R.id.fatid).text = list[position].fat.toString()
            findViewById<TextView>(R.id.kcalid).text = list[position].kcal.toString()
        }
    }

    override fun getItemCount(): Int = list.size
}