package be.uhasselt.iifymtracker

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import be.uhasselt.iifymtracker.databinding.FragmentExtra1Binding
import be.uhasselt.iifymtracker.databinding.FragmentExtra2Binding
import be.uhasselt.iifymtracker.model.MySharedData

class ExtraFragment2: Fragment(R.layout.fragment_extra2) {

    private lateinit var binding: FragmentExtra2Binding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_extra2, container, false)
    }
}