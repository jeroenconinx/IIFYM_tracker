package be.uhasselt.iifymtracker

data class Foodlist(
    val naam: String,
    var fat: Int,
    var carb: Int,
    var prot: Int,
) {
    var kcal: Int = 4*carb + 4*prot + 9*fat
}