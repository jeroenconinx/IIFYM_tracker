package be.uhasselt.iifymtracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import be.uhasselt.iifymtracker.databinding.ActivityExtraBinding
import be.uhasselt.iifymtracker.model.MySharedData


class ExtraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExtraBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExtraBinding.inflate(layoutInflater)

        setContentView(binding.root)
        val totalProteinConsumed = intent.getStringExtra("tekst")
        binding.textView.text = "Today's protein consumption so far is $totalProteinConsumed"

        val goal = 200
        val proteinLeftInG = goal - totalProteinConsumed.toString().toInt()
        var proteinLeftInKcal = proteinLeftInG*4

        val model = MySharedData()
        val fragment1 = ExtraFragment1(/*model*/)
        val fragment2 = ExtraFragment2(/*model*/)

        binding.frag1.setOnClickListener {switchto(fragment1)}
        binding.frag2.setOnClickListener {switchto(fragment2)}
        switchto(fragment1)

        supportFragmentManager.beginTransaction().replace(R.id.fragmentContainerView, fragment1).commit()
    }

    private fun switchto(fragment: Fragment){
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragmentContainerView, fragment)
            // if you want to add it to the "back stack" to support the back button, also call this.
            addToBackStack("Fragment_${fragment.id}")
            commit()
        }
    }
}