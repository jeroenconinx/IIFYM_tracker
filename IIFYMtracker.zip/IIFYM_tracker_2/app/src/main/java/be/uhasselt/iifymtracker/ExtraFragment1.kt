package be.uhasselt.iifymtracker

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import be.uhasselt.iifymtracker.databinding.FragmentExtra1Binding
import be.uhasselt.iifymtracker.model.MySharedData

class ExtraFragment1: Fragment(R.layout.fragment_extra1) {

    private lateinit var binding: FragmentExtra1Binding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_extra1, container, false)
    }
}