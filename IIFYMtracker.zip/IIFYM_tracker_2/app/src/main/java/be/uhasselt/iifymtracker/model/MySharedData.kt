package be.uhasselt.iifymtracker.model

data class MySharedData(var naame: String = "", var age: Int = 0)